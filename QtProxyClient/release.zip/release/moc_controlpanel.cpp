/****************************************************************************
** Meta object code from reading C++ file 'controlpanel.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.9.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../controlpanel.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'controlpanel.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.9.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_ControlPanel_t {
    QByteArrayData data[43];
    char stringdata0[1090];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_ControlPanel_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_ControlPanel_t qt_meta_stringdata_ControlPanel = {
    {
QT_MOC_LITERAL(0, 0, 12), // "ControlPanel"
QT_MOC_LITERAL(1, 13, 21), // "on_button_set_clicked"
QT_MOC_LITERAL(2, 35, 0), // ""
QT_MOC_LITERAL(3, 36, 24), // "on_pushButton_up_pressed"
QT_MOC_LITERAL(4, 61, 25), // "on_pushButton_up_released"
QT_MOC_LITERAL(5, 87, 22), // "on_radioButton_clicked"
QT_MOC_LITERAL(6, 110, 27), // "on_radioButton_tank_clicked"
QT_MOC_LITERAL(7, 138, 29), // "on_radioButton_custom_clicked"
QT_MOC_LITERAL(8, 168, 17), // "on_radio0_clicked"
QT_MOC_LITERAL(9, 186, 18), // "on_radio45_clicked"
QT_MOC_LITERAL(10, 205, 18), // "on_radio90_clicked"
QT_MOC_LITERAL(11, 224, 13), // "keyPressEvent"
QT_MOC_LITERAL(12, 238, 10), // "QKeyEvent*"
QT_MOC_LITERAL(13, 249, 5), // "event"
QT_MOC_LITERAL(14, 255, 15), // "keyReleaseEvent"
QT_MOC_LITERAL(15, 271, 18), // "on_tank_up_pressed"
QT_MOC_LITERAL(16, 290, 19), // "on_tank_up_released"
QT_MOC_LITERAL(17, 310, 20), // "on_tank_down_pressed"
QT_MOC_LITERAL(18, 331, 21), // "on_tank_down_released"
QT_MOC_LITERAL(19, 353, 28), // "on_pushButton_submit_clicked"
QT_MOC_LITERAL(20, 382, 26), // "on_pushButton_down_pressed"
QT_MOC_LITERAL(21, 409, 27), // "on_pushButton_down_released"
QT_MOC_LITERAL(22, 437, 27), // "on_pushButton_right_clicked"
QT_MOC_LITERAL(23, 465, 26), // "on_pushButton_left_clicked"
QT_MOC_LITERAL(24, 492, 30), // "on_button_submit_servo_clicked"
QT_MOC_LITERAL(25, 523, 25), // "on_button_left_up_pressed"
QT_MOC_LITERAL(26, 549, 26), // "on_button_left_up_released"
QT_MOC_LITERAL(27, 576, 30), // "on_button_left_up_down_pressed"
QT_MOC_LITERAL(28, 607, 31), // "on_button_left_up_down_released"
QT_MOC_LITERAL(29, 639, 27), // "on_button_left_down_pressed"
QT_MOC_LITERAL(30, 667, 28), // "on_button_left_down_released"
QT_MOC_LITERAL(31, 696, 26), // "on_button_right_up_pressed"
QT_MOC_LITERAL(32, 723, 27), // "on_button_right_up_released"
QT_MOC_LITERAL(33, 751, 31), // "on_button_right_down_up_pressed"
QT_MOC_LITERAL(34, 783, 32), // "on_button_right_down_up_released"
QT_MOC_LITERAL(35, 816, 28), // "on_button_right_down_pressed"
QT_MOC_LITERAL(36, 845, 29), // "on_button_right_down_released"
QT_MOC_LITERAL(37, 875, 30), // "on_button_middle_up_up_pressed"
QT_MOC_LITERAL(38, 906, 31), // "on_button_middle_up_up_released"
QT_MOC_LITERAL(39, 938, 34), // "on_button_middle_down_down_pr..."
QT_MOC_LITERAL(40, 973, 35), // "on_button_middle_down_down_re..."
QT_MOC_LITERAL(41, 1009, 39), // "on_horizontalSlider_speed_sli..."
QT_MOC_LITERAL(42, 1049, 40) // "on_horizontalSlider_speed_sli..."

    },
    "ControlPanel\0on_button_set_clicked\0\0"
    "on_pushButton_up_pressed\0"
    "on_pushButton_up_released\0"
    "on_radioButton_clicked\0"
    "on_radioButton_tank_clicked\0"
    "on_radioButton_custom_clicked\0"
    "on_radio0_clicked\0on_radio45_clicked\0"
    "on_radio90_clicked\0keyPressEvent\0"
    "QKeyEvent*\0event\0keyReleaseEvent\0"
    "on_tank_up_pressed\0on_tank_up_released\0"
    "on_tank_down_pressed\0on_tank_down_released\0"
    "on_pushButton_submit_clicked\0"
    "on_pushButton_down_pressed\0"
    "on_pushButton_down_released\0"
    "on_pushButton_right_clicked\0"
    "on_pushButton_left_clicked\0"
    "on_button_submit_servo_clicked\0"
    "on_button_left_up_pressed\0"
    "on_button_left_up_released\0"
    "on_button_left_up_down_pressed\0"
    "on_button_left_up_down_released\0"
    "on_button_left_down_pressed\0"
    "on_button_left_down_released\0"
    "on_button_right_up_pressed\0"
    "on_button_right_up_released\0"
    "on_button_right_down_up_pressed\0"
    "on_button_right_down_up_released\0"
    "on_button_right_down_pressed\0"
    "on_button_right_down_released\0"
    "on_button_middle_up_up_pressed\0"
    "on_button_middle_up_up_released\0"
    "on_button_middle_down_down_pressed\0"
    "on_button_middle_down_down_released\0"
    "on_horizontalSlider_speed_sliderPressed\0"
    "on_horizontalSlider_speed_sliderReleased"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_ControlPanel[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      39,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  209,    2, 0x08 /* Private */,
       3,    0,  210,    2, 0x08 /* Private */,
       4,    0,  211,    2, 0x08 /* Private */,
       5,    0,  212,    2, 0x08 /* Private */,
       6,    0,  213,    2, 0x08 /* Private */,
       7,    0,  214,    2, 0x08 /* Private */,
       8,    0,  215,    2, 0x08 /* Private */,
       9,    0,  216,    2, 0x08 /* Private */,
      10,    0,  217,    2, 0x08 /* Private */,
      11,    1,  218,    2, 0x08 /* Private */,
      14,    1,  221,    2, 0x08 /* Private */,
      15,    0,  224,    2, 0x08 /* Private */,
      16,    0,  225,    2, 0x08 /* Private */,
      17,    0,  226,    2, 0x08 /* Private */,
      18,    0,  227,    2, 0x08 /* Private */,
      19,    0,  228,    2, 0x08 /* Private */,
      20,    0,  229,    2, 0x08 /* Private */,
      21,    0,  230,    2, 0x08 /* Private */,
      22,    0,  231,    2, 0x08 /* Private */,
      23,    0,  232,    2, 0x08 /* Private */,
      24,    0,  233,    2, 0x08 /* Private */,
      25,    0,  234,    2, 0x08 /* Private */,
      26,    0,  235,    2, 0x08 /* Private */,
      27,    0,  236,    2, 0x08 /* Private */,
      28,    0,  237,    2, 0x08 /* Private */,
      29,    0,  238,    2, 0x08 /* Private */,
      30,    0,  239,    2, 0x08 /* Private */,
      31,    0,  240,    2, 0x08 /* Private */,
      32,    0,  241,    2, 0x08 /* Private */,
      33,    0,  242,    2, 0x08 /* Private */,
      34,    0,  243,    2, 0x08 /* Private */,
      35,    0,  244,    2, 0x08 /* Private */,
      36,    0,  245,    2, 0x08 /* Private */,
      37,    0,  246,    2, 0x08 /* Private */,
      38,    0,  247,    2, 0x08 /* Private */,
      39,    0,  248,    2, 0x08 /* Private */,
      40,    0,  249,    2, 0x08 /* Private */,
      41,    0,  250,    2, 0x08 /* Private */,
      42,    0,  251,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 12,   13,
    QMetaType::Void, 0x80000000 | 12,   13,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void ControlPanel::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        ControlPanel *_t = static_cast<ControlPanel *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->on_button_set_clicked(); break;
        case 1: _t->on_pushButton_up_pressed(); break;
        case 2: _t->on_pushButton_up_released(); break;
        case 3: _t->on_radioButton_clicked(); break;
        case 4: _t->on_radioButton_tank_clicked(); break;
        case 5: _t->on_radioButton_custom_clicked(); break;
        case 6: _t->on_radio0_clicked(); break;
        case 7: _t->on_radio45_clicked(); break;
        case 8: _t->on_radio90_clicked(); break;
        case 9: _t->keyPressEvent((*reinterpret_cast< QKeyEvent*(*)>(_a[1]))); break;
        case 10: _t->keyReleaseEvent((*reinterpret_cast< QKeyEvent*(*)>(_a[1]))); break;
        case 11: _t->on_tank_up_pressed(); break;
        case 12: _t->on_tank_up_released(); break;
        case 13: _t->on_tank_down_pressed(); break;
        case 14: _t->on_tank_down_released(); break;
        case 15: _t->on_pushButton_submit_clicked(); break;
        case 16: _t->on_pushButton_down_pressed(); break;
        case 17: _t->on_pushButton_down_released(); break;
        case 18: _t->on_pushButton_right_clicked(); break;
        case 19: _t->on_pushButton_left_clicked(); break;
        case 20: _t->on_button_submit_servo_clicked(); break;
        case 21: _t->on_button_left_up_pressed(); break;
        case 22: _t->on_button_left_up_released(); break;
        case 23: _t->on_button_left_up_down_pressed(); break;
        case 24: _t->on_button_left_up_down_released(); break;
        case 25: _t->on_button_left_down_pressed(); break;
        case 26: _t->on_button_left_down_released(); break;
        case 27: _t->on_button_right_up_pressed(); break;
        case 28: _t->on_button_right_up_released(); break;
        case 29: _t->on_button_right_down_up_pressed(); break;
        case 30: _t->on_button_right_down_up_released(); break;
        case 31: _t->on_button_right_down_pressed(); break;
        case 32: _t->on_button_right_down_released(); break;
        case 33: _t->on_button_middle_up_up_pressed(); break;
        case 34: _t->on_button_middle_up_up_released(); break;
        case 35: _t->on_button_middle_down_down_pressed(); break;
        case 36: _t->on_button_middle_down_down_released(); break;
        case 37: _t->on_horizontalSlider_speed_sliderPressed(); break;
        case 38: _t->on_horizontalSlider_speed_sliderReleased(); break;
        default: ;
        }
    }
}

const QMetaObject ControlPanel::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_ControlPanel.data,
      qt_meta_data_ControlPanel,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *ControlPanel::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *ControlPanel::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_ControlPanel.stringdata0))
        return static_cast<void*>(const_cast< ControlPanel*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int ControlPanel::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 39)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 39;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 39)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 39;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
